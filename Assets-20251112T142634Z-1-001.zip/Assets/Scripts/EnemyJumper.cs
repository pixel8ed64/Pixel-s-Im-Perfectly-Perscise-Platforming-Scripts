using UnityEngine;
using System.Collections;

public class EnemyJumper : MonoBehaviour
{
    public Rigidbody2D myRigidBody;
    private Animator myAnimator;
    public float forceY;
     void Start()
    {
        myRigidBody = GetComponent<Rigidbody2D>();
        myAnimator = GetComponent<Animator>();
        StartCoroutine(Attack());
    }

    IEnumerator Attack()
    {
        yield return new WaitForSeconds(Random.Range(2, 5));
        forceY = Random.Range(250, 550);
        myRigidBody.AddForce(new Vector2(0, forceY));
        myAnimator.SetBool("isJumping",true);
        yield return new WaitForSeconds(1.5f);
        myAnimator.SetBool("isJumping", false);
        StartCoroutine(Attack());
    }

}
